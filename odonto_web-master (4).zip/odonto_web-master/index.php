<?php
    
    header ("Location: view/dashboard.php");

?>