<!DOCTYPE html>
<html>
  <body class="hold-transition skin-blue sidebar-mini fixed">
    <div class="se-pre-con"></div>
    <?php include '../../view/util/menu.php'; ?>
    <div class="content-wrapper" id="sec">
    <section class="content" id="content">
    <div class="row">
    <section class="col-md-12 ">
      <div class="tab-pane active" >
      <div class="panel panel-default border-form" style="margin-bottom: 43px;">
        <div class="panel-body">
          <h4><strong>Tela Inicial</strong></h4>
          <br>
        </div>
      </div>
    </section>
  </body>
</html>