  <!-- Footer 
  <div class="footer">
        <footer class="page-footer teal darken-3">
            <div class="footer-copyright">
                <div class="container">
                    © 2020 Project Labs II
                    <a class="grey-text text-lighten-4 right" href="#!">Beta 1.0</a>
                </div>
            </div>
        </footer>
    </div>
     Footer -->